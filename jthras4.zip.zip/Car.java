/**
 * This class represents a Car with properties make, year, and price. It implements the Comparable interface
 * to allow Car objects to be compared with each other based on their make and year.
 *
 * CSC 1351 Programming Project No 7
 * Section 3
 *
 * @author jthras4
 * @since 16/03/2024
 */
public class Car implements Comparable<Car> {
    private String make; // Hold the make of the car
    private int year; // The manufactured year of the car
    private int price; // Price of the car


    /**
     * Constructs a new Car instance with the specified make, year, and price.
     *
     * @param Make The car's make.
     * @param Year The production year of the car.
     * @param Price The price of the car.
     */
    public Car(String Make, int Year, int Price){
        this.make = Make;
        this.year = Year;
        this.price = Price;
    }

    /**
     * Returns the car's make.
     *
     * @return A string representing the car's make.
     */
    public String getMake(){
        return make;
    }

    /**
     * Returns the car's manufactured year.
     *
     * @return An integer representing the year the car was produced.
     */
    public int getYear(){
        return year;
    }

    /**
     * Returns the car's price.
     *
     * @return An integer representing the car's price.
     */
    public int getPrice(){
        return price;
    }

    /**
     * Compares this car with another car based on the make. If the makes are identical,
     * then the year is used for comparison.
     *
     * @param other The Car object to be compared.
     * @return A negative integer, zero, or a positive integer
     */
    public int compareTo(Car other) {
        int compareByMake = this.make.compareTo(other.make);
        if (compareByMake == 0) {
            return Integer.compare(this.year, other.year);
        }
        return compareByMake;
    }

    /**
     * Returns a string representation of the Car instance
     *
     * @return A string containing the car's make, year, and price.
     */
    public String toString() {
        return "Make: " + make + ", Year: " + year + ", Price: " + price;
    }
}
